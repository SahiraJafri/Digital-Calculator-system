/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
import java.util.Stack;

class TreeNode {
    double value;
    String operator;
    TreeNode left, right;

    public TreeNode(double value) {
        this.value = value;
    }

    public TreeNode(String operator, TreeNode left, TreeNode right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    public static double evaluate(TreeNode root) {
        if (root == null) return 0;
        if (root.operator == null) return root.value;

        double left = evaluate(root.left);
        double right = evaluate(root.right);
        double result = 0;

        switch (root.operator) {
            case "+": result = left + right; break;
            case "-": result = left - right; break;
            case "*": result = left * right; break;
            case "/": result = left / right; break;
        }

        return result;
    }
}

public class Calculator {
    public static void main(String[] args) {
        CalculatorGUI calculatorGUI = new CalculatorGUI();
        calculatorGUI.setVisible(true);
    }

    public double calculate(String expression) {
        String postfix = infixToPostfix(expression);
        TreeNode root = buildTree(postfix);
        return TreeNode.evaluate(root);
    }

    private String infixToPostfix(String infix) {
        StringBuilder postfix = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (char ch : infix.toCharArray()) {
            if (Character.isDigit(ch) || ch == '.') {
                postfix.append(ch);
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix.append(" ").append(stack.pop());
                }
                stack.pop(); // Pop '('
            } else {
                postfix.append(" ");
                while (!stack.isEmpty() && getPrecedence(stack.peek()) >= getPrecedence(ch)) {
                    postfix.append(stack.pop()).append(" ");
                }
                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            postfix.append(" ").append(stack.pop());
        }

        return postfix.toString().trim();
    }

    private TreeNode buildTree(String postfix) {
        Stack<TreeNode> stack = new Stack<>();

        for (String token : postfix.split("\\s+")) {
            if (isNumber(token)) {
                stack.push(new TreeNode(Double.parseDouble(token)));
            } else if (isOperator(token)) {
                stack.push(new TreeNode(token, stack.pop(), stack.pop()));
            }
        }

        return stack.pop();
    }

    private int getPrecedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return 0; // for '('
        }
    }

    private boolean isNumber(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isOperator(String str) {
        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/");
    }
}
